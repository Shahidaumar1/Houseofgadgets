<?php

namespace App\Http\Livewire\Admin\Sell\Addon;

use App\Helpers\ImageService;
use App\Helpers\ServiceType;
use App\Models\Modal;
use App\Models\ProductSpec;
use Livewire\Component;
use Livewire\WithFileUploads;
use Illuminate\Support\Str;

class AddSpec extends Component
{
    use WithFileUploads;
    public $mobileMode =  true;
    public $tabletMode;
    public $consoleMode;
    public $laptopMode;
    public $watchMode;

    public $rand;
    public $model;
    public $product_specs;
    public $memory_sizes;
    public $conditions;
    public $colors;
    public $selectedMemorySize;
    public $selectedCondition;
    public $selectedColor;
    public $price;
    public $network_unlocked = false;
    public $image;

    // public $network_providers = ['Vodafone', 'Jazz', 'Telenor', 'Ufone', 'Zong', 'Warid'];
    public $network_providers = [
        ['name' => 'Vodafone', 'image' => 'https://ik.imagekit.io/li8bg5tjv3/jjjj-removebg-preview.png?updatedAt=1715001265394'],
        ['name' => 'o2', 'image' => 'https://ik.imagekit.io/li8bg5tjv3/o2.png?updatedAt=1714988339664'],
        ['name' => 'Smarty', 'image' => 'https://ik.imagekit.io/li8bg5tjv3/khuram.png?updatedAt=1714995835796'],
        ['name' => 'EE', 'image' => 'https://ik.imagekit.io/li8bg5tjv3/EE_logo.svg-removebg-preview.png?updatedAt=1715001352027'],
        ['name' => 'Asda', 'image' => 'https://ik.imagekit.io/li8bg5tjv3/3-removebg-preview.png?updatedAt=1714996032103'],
        ['name' => 'Tesco', 'image' => 'https://images.rawpixel.com/image_png_800/cHJpdmF0ZS9sci9pbWFnZXMvd2Vic2l0ZS8yMDIyLTEwL3JtNTM1YmF0Y2gyLXF1ZXN0aW9uLTAyLnBuZw.png']
    ];


    public $selectedNetwork = null;


    public function mount(Modal $model)
    {
        $this->model = $model;
        $this->loadSpecsData();
        $this->loadProductSpecs($model);
    }

    public function selectNetwork($network)
    {
        $this->selectedNetwork = $network;
    }

    public function selectMemorySize($memory_size)
    {
        $this->selectedMemorySize = $memory_size;
    }
    public function selectCondition($condition)
    {
        $this->selectedCondition = $condition;
    }
    public function selectColor($color)
    {
        $this->selectedColor = $color;
    }

    public function toggleNetworkUnlocked()
    {
        $this->network_unlocked = !$this->network_unlocked;
    }



    protected $listeners = ['modelId', 'productsEmited'];

    public function modelId(Modal $model)
    {
        $this->model = $model;
        $this->loadProductSpecs($model);
        $this->changeSpecForm();
    }

    public function productsEmited()
    {
        $this->loadProductSpecs($this->model);
    }



    // public function save()
    // {
    //     $this->validate([
    //         'price' => 'required',
    //         'selectedCondition' => 'required',
    //         'selectedNetwork' => 'required|in:' . implode(',', $this->network_providers), // Ensure valid network
    //     ]);
    //     $product_spec = ProductSpec::where('model_id', $this->model->id)->where('memory_size', $this->selectedMemorySize)->where('condition', $this->selectedCondition)->where('network_unlocked', $this->selectedNetwork)->first();
    //     if ($product_spec) {
    //         return $this->addError('error', 'Price already added for this specification');
    //     }
    //     $new_product_spec = new ProductSpec();
    //     $new_product_spec->memory_size = $this->selectedMemorySize ?? null;
    //     $new_product_spec->condition = $this->selectedCondition ?? null;
    //     $new_product_spec->price = $this->price;
    //     $new_product_spec->model_id = $this->model->id;
    //     $new_product_spec->service = ServiceType::SELL;
    //     // $new_product_spec->network_unlocked = $this->network_unlocked;
    //     $new_product_spec->network_unlocked = $this->selectedNetwork;
    //     if ($this->image) {
    //         $new_product_spec->image = ImageService::upload($this->image)->url;
    //     }
    //     $new_product_spec->save();
    //     $this->clear();
    //     $this->loadProductSpecs($this->model);
    //     $this->emit('productAdded');
    // }


    public function save()
    {
        // Validate with updated rules to ensure custom network is included
        $this->validate([
            'price' => 'required',
            'selectedCondition' => 'required',
            'selectedNetwork' => 'required', // Ensure network is required
        ]);

        // Create a new product specification if it doesn't exist
        $product_spec = ProductSpec::where('model_id', $this->model->id)
            ->where('memory_size', $this->selectedMemorySize)
            ->where('condition', $this->selectedCondition)
            ->where('network_unlocked', $this->selectedNetwork) // Consider the network
            ->first();

        if ($product_spec) {
            // Handle the case when a spec with the same condition already exists
            return $this->addError('error', 'Specification already exists with this network.');
        }

        // Create a new product spec with the custom network
        $new_product_spec = new ProductSpec();
        $new_product_spec->memory_size = $this->selectedMemorySize ?? null;
        $new_product_spec->condition = $this->selectedCondition ?? null;
        $new_product_spec->price = $this->price;
        $new_product_spec->model_id = $this->model->id;
        $new_product_spec->service = ServiceType::SELL;
        $new_product_spec->network_unlocked = $this->selectedNetwork; // Add custom network

        if ($this->image) {
            $new_product_spec->image = ImageService::upload($this->image)->url;
        }

        // Save the new product spec
        $new_product_spec->save();

        // Clear the form and reload specs
        $this->clear();
        $this->loadProductSpecs($this->model);
        $this->emit('productAdded'); // Emit event after product spec is added
    }


    public function clear()
    {
        $this->selectedMemorySize = null;
        $this->selectedCondition = null;
        $this->selectedColor = null;
        // $this->network_unlocked = false;
        $this->selectedNetwork = null;
        $this->price = null;
        $this->rand++;
    }
    public function loadProductSpecs($model)
    {
        $this->product_specs = ProductSpec::where('model_id', $model->id)->get();
    }
    public function loadSpecsData()
    {
        $this->memory_sizes = ['32 GB', '64 GB', '128 GB', '256 GB', '500 GB', '1 TB', '2 TB'];
        $this->conditions = ['Excellent', 'Good', 'Fair', 'Poor', 'Faulty'];
        $this->colors = ['Black', 'White', 'Red', 'Green', 'Yellow'];
    }

    public function changeSpecForm()
    {

        $this->mobileMode = Str::contains($this->model->device_type->category->name, 'Phone');
        $this->tabletMode = Str::contains($this->model->device_type->category->name, 'Tablet&Ipaid');
        $this->consoleMode = Str::contains($this->model->device_type->category->name, 'Console');
        $this->watchMode = Str::contains($this->model->device_type->category->name, 'Watch');
        $this->laptopMode = Str::contains($this->model->device_type->category->name, 'Laptop');
    }
    public function render()
    {
        return view('livewire.admin.sell.addon.add-spec');
    }
}

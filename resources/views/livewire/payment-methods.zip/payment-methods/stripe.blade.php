<div>

    {{-- ── Success Message ─────────────────────────────────────────────── --}}
    @if ($success)
        <div class="alert alert-success" role="alert">
            <h4 class="alert-heading">&#10003; Payment Successful!</h4>
            <p>Your payment was successfully processed. Admin will contact you soon.</p>
            <hr>
            <p class="mb-0">Thank you for your payment.</p>
        </div>
    @endif

    {{-- ── Error Message ────────────────────────────────────────────────── --}}
    @error('error')
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <strong>&#10007; Payment failed!</strong> {{ $message }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @enderror

    {{-- ═══════════════════════════════════════════════════════════════════ --}}
    {{-- WALLET SECTION — Google Pay / Apple Pay Button                    --}}
    {{-- ═══════════════════════════════════════════════════════════════════ --}}
    <div id="wallet-pay-section-{{ $this->id }}" style="display:none; margin-bottom:16px;">
        <div id="payment-request-button-{{ $this->id }}" wire:ignore></div>
        <p class="text-center text-muted mt-2" style="font-size:12px;">
            Your saved cards will load via your wallet
        </p>
    </div>

    {{-- ── Wallet not supported message ───────────────────────────────────── --}}
    <div id="wallet-not-supported-{{ $this->id }}" style="display:none;">
        <div class="alert alert-warning" style="font-size:13px;">
            &#9888; Google Pay / Apple Pay is not available in this browser. Please pay with card instead.
        </div>
    </div>

    {{-- ═══════════════════════════════════════════════════════════════════ --}}
    {{-- CARD FORM                                                          --}}
    {{-- ═══════════════════════════════════════════════════════════════════ --}}
    <div id="card-form-wrapper-{{ $this->id }}"
         style="{{ $mode === 'googlepay' || $mode === 'applepay' ? 'display:none;' : '' }}">
        <form id="payment-form-{{ $this->id }}" class="w-100">
            @csrf
            <div class="d-flex gap-2 flex-column" style="padding: 0 10px;">

                <div id="card-element-{{ $this->id }}" wire:ignore
                     style="padding:12px; border:1px solid #ced4da; border-radius:6px; background:#fff;"></div>

                <div id="card-errors-{{ $this->id }}" role="alert"
                     style="color:#dc3545; font-size:13px; min-height:18px;"></div>

                <button type="submit" class="btn btn-{{ $color ?? 'primary' }} mt-1"
                    @if ($loading || $price == 0) disabled @endif>
                    <div class="d-flex gap-2 justify-content-center align-items-center">
                        &#128179; Submit Payment
                        @if ($loading)
                            <span><x-spinner color="white" /></span>
                        @endif
                    </div>
                </button>
            </div>
        </form>

        <div class="form-check mt-3" style="padding-left:24px;">
            <input class="form-check-input" type="checkbox" value=""
                   id="stripeAgreeCheck-{{ $this->id }}" checked />
            <label class="form-check-label" for="stripeAgreeCheck-{{ $this->id }}"
                   style="font-size:13px; color:#555;">
                I agree to the
                <a href="{{ route('privacy-and-policy') }}" style="color:#007bff;">Privacy Policy</a>
                and
                <a href="{{ route('terms-and-conditions') }}" style="color:#007bff;">Terms &amp; Conditions</a>
            </label>
        </div>
    </div>

    {{-- ═══════════════════════════════════════════════════════════════════ --}}
    {{-- Stripe JS                                                          --}}
    {{-- ═══════════════════════════════════════════════════════════════════ --}}
    <div wire:ignore>
        <script src="https://js.stripe.com/v3/"></script>
        <script>
        (function () {
            var COMPONENT_ID    = '{{ $this->id }}';
            var stripePublicKey = '{{ $public_key }}';
            var isWalletMode    = ('{{ $mode }}' === 'googlepay' || '{{ $mode }}' === 'applepay');

            var stripe   = Stripe(stripePublicKey);
            var elements = stripe.elements();

            // ══════════════════════════════════════════════════════════════════
            // CARD MODE
            // ══════════════════════════════════════════════════════════════════
            if (!isWalletMode) {
                var card = null;

                function mountCard() {
                    var cardElementDiv = document.getElementById('card-element-' + COMPONENT_ID);
                    if (!cardElementDiv) return;

                    // Pehle wala unmount/destroy karo
                    if (card) {
                        try { card.unmount(); } catch(e) {}
                        try { card.destroy(); } catch(e) {}
                    }

                    // Div clear karo
                    cardElementDiv.innerHTML = '';

                    // Naya card element banao aur mount karo
                    card = elements.create('card', {
                        style: {
                            base: {
                                fontSize: '16px',
                                color: '#32325d',
                                '::placeholder': { color: '#aab7c4' },
                            },
                            invalid: { color: '#dc3545' },
                        },
                        hidePostalCode: true,
                    });
                    card.mount('#card-element-' + COMPONENT_ID);

                    card.on('change', function(event) {
                        var el = document.getElementById('card-errors-' + COMPONENT_ID);
                        if (el) el.textContent = event.error ? event.error.message : '';
                    });
                }

                // Pehli baar mount karo
                mountCard();

                // Jab bhi card wrapper visible ho — remount karo
                var cardWrapperEl = document.getElementById('card-form-wrapper-' + COMPONENT_ID);
                if (cardWrapperEl) {
                    var observer = new MutationObserver(function(mutations) {
                        mutations.forEach(function(mutation) {
                            if (mutation.attributeName === 'style') {
                                if (cardWrapperEl.style.display !== 'none') {
                                    setTimeout(mountCard, 50);
                                }
                            }
                        });
                    });
                    observer.observe(cardWrapperEl, { attributes: true });
                }

                var form = document.getElementById('payment-form-' + COMPONENT_ID);
                if (form) {
                    form.addEventListener('submit', function (event) {
                        event.preventDefault();
                        if (!card) return;
                        stripe.createToken(card).then(function (result) {
                            if (result.error) {
                                document.getElementById('card-errors-' + COMPONENT_ID).textContent = result.error.message;
                            } else {
                                livewire.emit('tokenCreated', result.token.id);
                            }
                        });
                    });
                }
            }

            // ══════════════════════════════════════════════════════════════════
            // WALLET MODE — Google Pay / Apple Pay
            // ══════════════════════════════════════════════════════════════════
            if (isWalletMode) {

                function initWalletButton(clientSecret, amount, label) {
                    var paymentRequest = stripe.paymentRequest({
                        country:  'GB',
                        currency: 'gbp',
                        total:    { label: label, amount: amount },
                        requestPayerName:  false,
                        requestPayerEmail: false,
                    });

                    var prButton = elements.create('paymentRequestButton', {
                        paymentRequest: paymentRequest,
                        style: {
                            paymentRequestButton: {
                                type:   'default',
                                theme:  'dark',
                                height: '56px',
                            },
                        },
                    });

                    paymentRequest.canMakePayment().then(function (result) {
                        var walletSection = document.getElementById('wallet-pay-section-' + COMPONENT_ID);
                        var notSupported  = document.getElementById('wallet-not-supported-' + COMPONENT_ID);
                        var cardWrap      = document.getElementById('card-form-wrapper-' + COMPONENT_ID);

                        if (result) {
                            prButton.mount('#payment-request-button-' + COMPONENT_ID);
                            if (walletSection) walletSection.style.display = 'block';
                        } else {
                            // Browser wallet support nahi karta — fallback card form
                            if (cardWrap)     cardWrap.style.display     = 'block';
                            if (notSupported) notSupported.style.display = 'block';
                        }
                    });

                    paymentRequest.on('paymentmethod', function (ev) {
                        stripe.confirmCardPayment(
                            clientSecret,
                            { payment_method: ev.paymentMethod.id },
                            { handleActions: false }
                        ).then(function (confirmResult) {
                            if (confirmResult.error) {
                                ev.complete('fail');
                                var errEl = document.getElementById('card-errors-' + COMPONENT_ID);
                                if (errEl) errEl.textContent = confirmResult.error.message;
                            } else {
                                ev.complete('success');
                                if (confirmResult.paymentIntent.status === 'requires_action') {
                                    stripe.confirmCardPayment(clientSecret).then(function (result) {
                                        if (result.error) {
                                            var errEl = document.getElementById('card-errors-' + COMPONENT_ID);
                                            if (errEl) errEl.textContent = result.error.message;
                                        } else {
                                            @this.call('confirmWalletPayment', result.paymentIntent.id);
                                        }
                                    });
                                } else {
                                    @this.call('confirmWalletPayment', confirmResult.paymentIntent.id);
                                }
                            }
                        });
                    });
                }

                // payment-intent-ready event sun'o
                window.addEventListener('payment-intent-ready', function (e) {
                    initWalletButton(e.detail.clientSecret, e.detail.amount, e.detail.label);
                });

                // createPaymentIntent call karo — page load ke baad
                function callCreateIntent() {
                    @this.call('createPaymentIntent');
                }

                if (document.readyState === 'complete') {
                    setTimeout(callCreateIntent, 100);
                } else {
                    window.addEventListener('load', function () {
                        setTimeout(callCreateIntent, 100);
                    });
                }

                // Price change pe naya PaymentIntent
                window.addEventListener('price', function () {
                    @this.call('createPaymentIntent');
                });
            }

        })();
        </script>
    </div>

</div>

<style>
    #card-element { transition: border-color 0.2s ease; }
    #card-element:focus-within {
        border-color: #80bdff !important;
        box-shadow: 0 0 0 3px rgba(0,123,255,.15);
    }
</style>
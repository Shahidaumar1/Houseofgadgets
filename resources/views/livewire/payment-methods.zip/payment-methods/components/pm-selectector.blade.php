<div>
    {{-- ── Payment Method Icons / Tabs ──────────────────────────────────── --}}
    <div class="d-flex gap-3 align-items-center justify-content-start mb-4 flex-wrap">

        {{-- Stripe (Card) --}}
        <span class="cursor-pointer" wire:click="changePm('stripe')" title="Pay with Card"
              style="display:inline-flex; align-items:center; justify-content:center;
                     width:60px; height:40px; border:2px solid {{ $selectedPm == 'stripe' ? '#198754' : '#ccc' }};
                     border-radius:8px; background:#fff; padding:5px; cursor:pointer;
                     {{ $selectedPm == 'stripe' ? 'box-shadow:0 0 0 2px #19875440;' : '' }}">
            <i class="fa fa-credit-card" style="font-size:22px; color:{{ $selectedPm == 'stripe' ? '#198754' : '#555' }};"></i>
        </span>

        {{-- PayPal --}}
        <span class="cursor-pointer" wire:click='changePm("paypal")' title="PayPal"
              style="display:inline-flex; align-items:center; justify-content:center;
                     width:60px; height:40px; border:2px solid {{ $selectedPm == 'paypal' ? '#198754' : '#ccc' }};
                     border-radius:8px; background:#fff; padding:5px; cursor:pointer;
                     {{ $selectedPm == 'paypal' ? 'box-shadow:0 0 0 2px #19875440;' : '' }}">
            <i class="fa fa-paypal" style="font-size:26px; color:{{ $selectedPm == 'paypal' ? '#198754' : '#003087' }};"></i>
        </span>

        {{-- Google Pay --}}
        <span class="cursor-pointer" wire:click='changePm("googlepay")' title="Google Pay"
              style="display:inline-flex; align-items:center; justify-content:center;
                     width:60px; height:40px; border:2px solid {{ $selectedPm == 'googlepay' ? '#198754' : '#ccc' }};
                     border-radius:8px; background:#fff; padding:5px; cursor:pointer;
                     {{ $selectedPm == 'googlepay' ? 'box-shadow:0 0 0 2px #19875440;' : '' }}">
            <img src="https://upload.wikimedia.org/wikipedia/commons/f/f2/Google_Pay_Logo.svg"
                 alt="Google Pay" style="height:20px; width:auto; object-fit:contain;" />
        </span>

        {{-- Apple Pay --}}
        <span class="cursor-pointer" wire:click='changePm("applepay")' title="Apple Pay"
              style="display:inline-flex; align-items:center; justify-content:center;
                     width:60px; height:40px; border:2px solid {{ $selectedPm == 'applepay' ? '#198754' : '#ccc' }};
                     border-radius:8px; background:#000; padding:5px; cursor:pointer;
                     {{ $selectedPm == 'applepay' ? 'box-shadow:0 0 0 2px #19875440;' : '' }}">
            <img src="https://upload.wikimedia.org/wikipedia/commons/b/b0/Apple_Pay_logo.svg"
                 alt="Apple Pay" style="height:20px; width:auto; object-fit:contain; filter:invert(1);" />
        </span>

        {{-- Klarna --}}
        <span class="cursor-pointer" wire:click='changePm("klarna")' title="Pay with Klarna"
              style="display:inline-flex; align-items:center; justify-content:center;
                     width:60px; height:40px; border:2px solid {{ $selectedPm == 'klarna' ? '#198754' : '#ccc' }};
                     border-radius:8px; background:#FFB3C7; padding:5px; cursor:pointer;
                     {{ $selectedPm == 'klarna' ? 'box-shadow:0 0 0 2px #19875440;' : '' }}">
            <span style="font-weight:800; font-size:13px; color:#000; letter-spacing:-0.5px;">Klarna</span>
        </span>

    </div>

    {{-- ── Hint label for selected method ──────────────────────────────── --}}
    <div class="mb-3" style="font-size:13px; color:#777;">
        @if ($selectedPm == 'stripe')
            <span>&#128179; Pay securely with your debit or credit card</span>
        @elseif ($selectedPm == 'paypal')
            <span>&#128180; Pay via your PayPal account</span>
        @elseif ($selectedPm == 'googlepay')
            <span>&#128241; Google Pay button automatically appear hoga agar browser support karta ho</span>
        @elseif ($selectedPm == 'applepay')
            <span>&#127822; Apple Pay — Safari aur Apple device required</span>
        @elseif ($selectedPm == 'klarna')
            <span>&#128717; Buy now, pay later with Klarna</span>
        @endif
    </div>

    {{-- ── Render selected payment component ───────────────────────────── --}}
    @if ($selectedPm == 'stripe')
        <livewire:payment-methods.stripe :price="$price" :color="$color" :service="$service" />

    @elseif ($selectedPm == 'paypal')
        <livewire:payment-methods.paypal :price="$price" :color="$color" :service="$service" />

    @elseif ($selectedPm == 'googlepay')
        <livewire:payment-methods.stripe :price="$price" :color="$color" :service="$service" />
        <div class="alert alert-info mt-2" style="font-size:13px;">
            <i class="fa fa-info-circle"></i>
            Google Pay button automatically dikh jaayega agar aapka Chrome/Android device support karta ho.
            Agar nahi dikh raha toh card se pay karein.
        </div>

    @elseif ($selectedPm == 'applepay')
        <livewire:payment-methods.stripe :price="$price" :color="$color" :service="$service" />
        <div class="alert alert-info mt-2" style="font-size:13px;">
            <i class="fa fa-info-circle"></i>
            Apple Pay button automatically aayega agar aap Safari browser aur Apple device use kar rahe hain.
        </div>

    @elseif ($selectedPm == 'klarna')
        <livewire:payment-methods.klarna :price="$price" :color="$color" :service="$service" />

    @endif

</div>

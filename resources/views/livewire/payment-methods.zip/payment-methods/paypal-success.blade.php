<div>
    <livewire:components.top-bar />

    <div class="container">
        <livewire:components.mega-nav />
        <div class="col-md-8 mx-auto my-5">

            @if ($status === 'processing')
                <div class="alert alert-info" role="alert">
                    <h4 class="alert-heading">Processing Payment...</h4>
                    <p>Please wait while we confirm your payment.</p>
                </div>

            @elseif ($status === 'success')
                <div class="alert alert-success" role="alert">
                    <h4 class="alert-heading">🎉 Payment Successful!</h4>
                    <p>Your PayPal payment has been confirmed. Admin will contact you soon.</p>
                    <hr>
                    <p class="mb-0">Thank you for choosing us. Questions? Reach out anytime.</p>
                </div>

            @elseif ($status === 'failed')
                <div class="alert alert-danger" role="alert">
                    <h4 class="alert-heading">Payment Failed</h4>
                    <p>{{ $message ?? 'Something went wrong. Please try again.' }}</p>
                    <hr>
                    <a href="{{ route('home') }}" class="btn btn-outline-danger btn-sm">Go Back</a>
                </div>
            @endif

        </div>
    </div>
</div>
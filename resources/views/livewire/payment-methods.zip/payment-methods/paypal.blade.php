<div>

    {{-- ── Success ──────────────────────────────────────────────────────── --}}
    @if ($success)
        <div class="alert alert-success text-center mt-2">
            <strong>&#10003; PayPal Payment Successful!</strong> Your booking has been confirmed.
        </div>
    @endif

    {{-- ── Error ───────────────────────────────────────────────────────── --}}
    @error('error')
        <div class="alert alert-danger alert-dismissible fade show mt-2" role="alert">
            <strong>Error:</strong> {{ $message }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @enderror

    {{-- ── Terms & Conditions ───────────────────────────────────────────── --}}
    <div class="d-flex align-items-center justify-content-center gap-2 mt-3 mb-3">
        <input type="checkbox" id="paypalAgree" wire:model="agreed"
               style="width:18px; height:18px; accent-color:#003087; cursor:pointer; flex-shrink:0;">
        <label for="paypalAgree" style="margin:0; font-size:14px; color:#333; cursor:pointer;">
            I agree to the
            <a href="{{ route('privacy-and-policy') }}" target="_blank" style="color:#007bff;">Privacy Policy</a>
            and
            <a href="{{ route('terms-and-conditions') }}" target="_blank" style="color:#007bff;">Terms &amp; Conditions</a>
        </label>
    </div>

    {{-- ── PayPal Button ────────────────────────────────────────────────── --}}
    <div class="d-flex justify-content-center mt-2">
        <button
            id="paypal-pay-btn"
            wire:click="createPaypalIntent"
            wire:loading.attr="disabled"
            class="btn btn-warning"
            style="width:260px; font-weight:700; font-size:16px; border-radius:8px; padding:12px 20px;"
            @if($loading) disabled @endif>
            <span wire:loading.remove wire:target="createPaypalIntent" class="d-flex align-items-center justify-content-center gap-2">
                <img src="https://upload.wikimedia.org/wikipedia/commons/a/a4/Paypal_2014_logo.png"
                     style="height:22px; width:auto;" alt="PayPal">
                Pay with PayPal
            </span>
            <span wire:loading wire:target="createPaypalIntent" class="d-flex align-items-center justify-content-center gap-2">
                <span class="spinner-border spinner-border-sm"></span> Please wait...
            </span>
        </button>
    </div>

    <p class="text-center text-muted mt-2" style="font-size:12px;">
        You will be redirected to PayPal to complete your payment securely.
    </p>

    {{-- ── Stripe JS — PayPal via Stripe ──────────────────────────────── --}}
    <div wire:ignore>
        <script src="https://js.stripe.com/v3/"></script>
        <script>
        (function () {
            var stripePublicKey = '{{ $public_key }}';
            if (!stripePublicKey) return;

            var stripe = Stripe(stripePublicKey);

            // Stripe ne paypal-intent-ready bheja (PHP se dispatchBrowserEvent)
            window.addEventListener('paypal-intent-ready', function (e) {
                var clientSecret = e.detail.clientSecret;
                var returnUrl    = e.detail.returnUrl;

                stripe.confirmPayPalPayment(clientSecret, {
                    return_url: returnUrl,
                }).then(function (result) {
                    if (result.error) {
                        // JS error — Livewire ko bhejo
                        @this.addError('error', result.error.message);
                        @this.set('loading', false);
                    } else if (result.paymentIntent && result.paymentIntent.status === 'succeeded') {
                        // Payment complete — confirm karo
                        @this.call('confirmPaypalPayment', result.paymentIntent.id);
                    }
                });
            });
        })();
        </script>
    </div>

</div>
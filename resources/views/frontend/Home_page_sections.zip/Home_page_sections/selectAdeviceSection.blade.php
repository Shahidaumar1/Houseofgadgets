<div>
      <style>
      /* custom-sec1 css start */
      .custom-sec1 {
          transform: translateY(-100px);
          padding: 0 15px;
           float: left;
      }

      .custom-sec1-content {
          max-width: 1128px;
          border-radius: 20px;
          background-color: #EA1555;
          padding: 35px 15px 42px 15px;
          display: block;
          margin: 0 auto;
      }

      .custom-sec1-inner {
          max-width: 770px;
          margin: 0 auto;

      }

      .custom-sec1-inner h4 {
          font-size: 24px;
          line-height: 30px;
          font-family: "Manrope", serif;  
          font-style: normal;
          margin: 0 !important;
          padding-bottom: 29px;
          color: white;
      }

      .custom-sec1-inner .select-device-box {
          display: flex;
      }

      .custom-sec1-inner .select-device-box select {
          width: 238px;
          height: 56px;
          display: flex;
          align-items: center;
          font-size: 20px;
          font-weight: 500;
          line-height: 27.32px;
          border-radius: 10PX;
          background: #F9F9F9;
          color: #525252;
          border: 0;
          outline: 0;
          appearance: none;
          position: relative;
          padding: 0 15px;
      }

      .custom-sec1-inner .select-device-box select:nth-child(2) {
          margin: 0 53px;
      }

      .custom-sec1-inner .select-device-box button {
          width: 170px;
          height: 56px;
          display: flex;
          align-items: center;
          font-size: 20px;
          font-weight: 500;
          line-height: 27.32px;
          border-radius: 10PX;
          background: #F9F9F9;
          color: #EA1555;
          border: 0;
          outline: 0;
      }

      @media(max-width:1176px) {
          .custom-sec1-content {
              max-width: 888px;
          }
      }

      @media(max-width:991px) {
          .custom-sec1 {
              transform: translateY(-48px);
              padding: 0 10px;
          }

          .custom-sec1-inner h4 {
              font-size: 14px;
              padding-bottom: 13px;
              text-align: center;
          }

          .custom-sec1-content {
              border-radius: 10px;
              max-width: 536px;
              padding: 12px 10px 13px 0px;
          }

          .custom-sec1-inner .select-device-box {
              justify-content: center;
          }

          .custom-sec1-inner .select-device-box select {
              width: 94px;
              height: 29px;
              font-size: 12px;
              line-height: 16.39px;
              border-radius: 5px;
          }

          .custom-sec1-inner .select-device-box select:nth-child(2) {
              margin: 0 13px;
          }

          .custom-sec1-inner .select-device-box button {
              width: 94px;
              height: 29px;
              font-size: 12px;
              line-height: 16.39px;
              border-radius: 5px;
          }
      }

      @media(max-width: 576px) {
          .custom-sec1 {
              transform: translateY(-40px);
          }

          .custom-sec1-content {
              max-width: 340px;
          }

          .custom-sec1-inner h4 {
              padding-bottom: 10px;
              line-height: 17px;
          }

          .custom-sec1-inner .select-device-box select {
              width: 66px;
              height: 25px;
              font-size: 8px;
              line-height: 10.93px;
              padding: 0 5px;
          }

          .custom-sec1-inner .select-device-box select:nth-child(2) {
              margin: 0 9px;
          }

          .custom-sec1-inner .select-device-box button {
              width: 66px;
              height: 25px;
              font-size: 8px;
              line-height: 10.93px;
          }
      }

      /* custom-sec1 css end */
  </style>
  <!--custom-sec1 select devise section start -->
  <section class="custom-sec1 w-100 float-left d-block">
      <div class="custom-sec1-content">
          <div class="custom-sec1-inner">
              <h4>Select Device ,Model for Repairing.</h4>
              <div class="select-device-box">
                  <select id="device" name="device" onchange="updateModalOptions()">
                      <option value="">Select Brand</option>
                      @php
                      $devices = \App\Models\DeviceType::whereHas('category', function ($query) {
                      $query->where('service', \App\Helpers\ServiceType::REPAIR)->where('status', 'Publish');
                      })->where('status', 'Publish')->get();
                      @endphp
                      @foreach($devices as $device)
                      <option value="{{ $device->id }}" {{ $device->id == request('device') ? 'selected' : '' }}>
                          {{ $device->name }}
                      </option>
                      @endforeach
                  </select>
                  <select id="modal" name="modal">
                      <option selected>Select Model</option>
                  </select>
                  <button type="button" class="btn" onclick="redirectToRepairTypes()">
                      <i class="fa fa-search pe-2" aria-hidden="true"></i> Search
                  </button>
              </div>

          </div>
      </div>
  </section>
  <script>
      const modalsData = @json(\App\Models\Modal:: where('status', 'Publish') -> get());
      function updateModalOptions() {
          const deviceId = document.getElementById('device').value;
          const modalSelect = document.getElementById('modal');
          modalSelect.innerHTML = '<option value="">Select Model</option>';

          if (deviceId) {
              const filteredModals = modalsData.filter(modal => modal.device_type_id == deviceId);
              filteredModals.forEach(modal => {
                  const option = document.createElement('option');
                  option.value = modal.id;
                  option.textContent = modal.name;
                  modalSelect.appendChild(option);
              });
          }
      }

      function redirectToRepairTypes() {
          const deviceId = document.getElementById('device').value;
          const modalId = document.getElementById('modal').value;

          if (deviceId && modalId) {
              const url = `{{ url('{device}/{modal}/repair_types') }}`.replace('{device}', deviceId).replace('{modal}', modalId);
              window.location.href = url;
          } else {
              alert('Please select both device and model.');
          }
      }
  </script>
  <!--custom-sec1 select devise section end -->
</div>
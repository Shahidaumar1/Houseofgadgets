
<div>
  
  <style>
      /* manorop */
      @import url('https://fonts.googleapis.com/css2?family=Manrope:wght@200..800&display=swap');
      /* manual font */
      @import url('https://fonts.googleapis.com/css2?family=Manuale:ital,wght@0,300..800;1,300..800&display=swap');

      /* home banner sec css start */
      .home-banner-sec {
          padding: 72px 15px 155px 15px;
          background-image: url("https://ik.imagekit.io/myfirstKit/irepairLondon/bannerSecImages/Home.png?updatedAt=1731255413364");
          background-position: right top;
          background-repeat: no-repeat;
          background-color:#fff;
          background-size: cover;
          box-shadow: 0px 0px 2px 0px #00000040;
          float: left;
      }
       

      .custom-container {
          max-width: 1283px;
          margin: 0 auto;
      }

      .banner-content {
          display: grid;
          grid-template-columns: 1fr 1fr;
          align-items: center;
      }

      .banner-content .content-box1 {
          display: flex;
          flex-direction: column;
          max-width: 650px;
      }

      .banner-content .content-box1 h2 {
          font-size: 40px;
          line-height: 54.64px;
          font-weight: 700;
          padding-bottom: 50px;
          margin: 0 !important;
          font-family: "Manrope", serif;  
          font-style: normal;
      }

      .banner-btns-box1 {
          display: flex;
          margin-bottom: 51px;
      }

      .banner-btns-box1 a {
          width: 215px;
          height: 65px;
          font-size: 17px;
          line-height: 27.32px;
          text-decoration: none;
          font-weight: 500;
          display: flex;
          flex-direction: row;
          align-items: center;
          justify-content: center;
          border-radius: 10px;
          transition: 0.3s ease;
          font-family: "Manrope", serif;  
          font-style: normal;
      }

      .banner-btns-box1 a:nth-child(1) {
          background: #EA1555;
          color: white !important;
          border: 1px solid #EA1555;
          font-family: "Manrope", serif;  
          font-style: normal;
      }

      .banner-btns-box1 a:nth-child(2) {
          margin-left: 34px;
          background: #fff;
          color: #000 !important;
          border: 1px solid #000;
          font-family: "Manrope", serif;  
          font-style: normal;
      }

      .banner-btns-box1 a:nth-child(1):hover {
          background: #fff;
          color: #000 !important;
          border: 1px solid #000;
      }

      .banner-btns-box1 a:nth-child(2):hover {
          background: #EA1555;
          color: white !important;
          border: 1px solid #EA1555;
      }

      .review-banner-btn {
          font-family: "Manrope", serif;  
          font-style: normal;
          width: 421px;
          height: 65px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 17px;
          line-height: 27.32px;
          text-decoration: none;
          font-weight: 500;
          border-radius: 10px;
          color: #000;
          border: 1px solid black;
      }

      .review-banner-btn:hover {
          background: #EA1555;
          color: white !important;
          border: 1px solid #EA1555;
      }

      .review-banner-btn .banner-stars {
          padding: 0 20px;
      }

      .review-banner-btn .banner-stars i {
          color: #FABB05 !important;
          font-size: 15px;
      }

      @media(max-width: 991px) {
          .home-banner-sec {
              padding: 50px 15px 98px 15px;
          }

          .banner-content {
              grid-template-columns: 1fr;
              justify-content: center;
          }

          .banner-content .content-box1 {
              max-width: 567px;
              margin: 0 auto;
              align-items: center;
          }

          .banner-content .content-box1 h2 {
              font-size: 36px;
              line-height: 46.64px;
              padding-bottom: 34px;
              text-align: center;
          }

          .banner-btns-box1 {
              margin-bottom: 13px;
          }

          .banner-btns-box1 i {
              font-size: 11px;
          }

          .banner-btns-box1 a {
              width: 137px;
              height: 40px;
              font-size: 15px;
              border-radius: 5px;
          }

          .review-banner-btn {
              width: 100%;
              max-width: 324px;
              height: 40px;
              font-size: 15px;
              line-height: 21.32px;
              border-radius: 5px;
          }

          .review-banner-btn .banner-stars i {
              font-size: 13px;
          }

          .banner-btns-box1 a:nth-child(2) {
              margin-left: 8px;
          }
      }

      @media(max-width: 768px) {
          .banner-content .content-box1 h2 {
              font-size: 32px;
              line-height: 37.64px;
              padding-bottom: 30px;
          }

          .review-banner-btn .banner-stars {
              padding: 0 10px;
          }
      }


      @media(max-width: 576px) {
          .banner-content .content-box1 h2 {
              font-size: 26px;
              line-height: 32.64px;
              padding-bottom: 25px;
          }

          .review-banner-btn,
          .banner-btns-box1 a {
              font-size: 13px;
          }

          .home-banner-sec {
              padding: 40px 15px 80px 15px;
          }
      }


      /* home banner css end */
  </style>
  <!-- banner section start -->
  <section class="home-banner-sec w-100 float-left d-block">
      <div class="custom-container">
          <div class="banner-content">
              <div class="content-box1">
                  <h2>Your One-Stop Shop for Buying, Selling, and Repairing Devices</h2>
                  <div class="banner-btns-box1"><a href="/categories"> Book a Repair <i
                              class="fa-solid fa-arrow-right ms-2"></i></a> </div>
                  <a class="review-banner-btn" href="https://g.page/r/CfOfxcVlgqJAEBM/review" target="blank">
                      <span>Review us</span>
                      <span class="banner-stars">
                      <strong> 5.0 </strong>
                          <i class="fa-solid fa-star"></i>
                          <i class="fa-solid fa-star"></i>
                          <i class="fa-solid fa-star"></i>
                          <i class="fa-solid fa-star"></i>
                          <i class="fa-solid fa-star"></i>
                           <strong>656</strong> 
                      </span>
                      <span>  Google Reviews</span>
                     </a>
              </div>
              <!-- Replace the <figure> in your .banner-content div with this -->
<div class="slider-container d-none d-lg-block">
    <!-- Bootstrap Carousel -->
    <div id="homepageCarousel" class="carousel slide" data-bs-ride="carousel">
        <!-- Pagination Indicators -->
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#homepageCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#homepageCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#homepageCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
            <button type="button" data-bs-target="#homepageCarousel" data-bs-slide-to="3" aria-label="Slide 4"></button>

        </div>
        <!-- Slider Content -->
        <div class="carousel-inner">
            <div class="carousel-item active ">
                <img src="https://ik.imagekit.io/kqeykkpy5/1.png?updatedAt=1743232568115" class="d-block" height="300px" width="500px" alt="iPhone">
            </div>
            <div class="carousel-item">
                <img src="https://ik.imagekit.io/kqeykkpy5/3.png?updatedAt=1743232565345" class="d-block" height="300px" width="500px"  alt="Huawei">
            </div>
            <div class="carousel-item">
                <img src="https://ik.imagekit.io/kqeykkpy5/4.png?updatedAt=1743232568572" class="d-block" height="300px" width="500px"  alt="Google">
            </div>
              <div class="carousel-item">
                <img src="https://ik.imagekit.io/kqeykkpy5/5.png" class="d-block" height="300px" width="500px"  alt="Samsung">
            </div>
        </div>
        <!-- Navigation Arrows -->
        <button class="carousel-control-prev" type="button" data-bs-target="#homepageCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#homepageCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    <!-- Samsung S25 Ultra Image -->

</div>

<style>
    /* Slider and Image Specific Styles */
    .slider-container {
        max-width: 500px;
        margin: 0 auto;
    }
    .carousel-inner img {
        width: 500px;
        height: 300px;
        object-fit: cover;
    }
    .carousel-indicators {
        position: static;
        margin-top: 10px;
    }
    .carousel-indicators button {
        width: 12px;
        height: 12px;
        border-radius: 50%;
    }
    .carousel-indicators .active {
        background-color: #EA1555; /* Matches your button color */
    }
    .single-image {
        margin-top: 20px;
        text-align: center;
    }
    .single-image img {
        max-width: 100%;
        height: auto;
    }
</style>
          </div>
      </div>
  </section>

</div>
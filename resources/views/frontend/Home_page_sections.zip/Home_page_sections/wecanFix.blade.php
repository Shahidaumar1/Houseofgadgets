<div>
      <style>
        /* custom- sec 3 comprehensive solution section start */
        .custom-sec3 {
            display: block;
            float: left;
            width: 100%;
            padding: 0px 15px 72px 15px;
            text-align: center;
        }

        .custom-container {
            max-width: 1283px;
            margin: 0 auto;
        }

        .custom-sec3-main small {
            font-size: 18px;
            font-family: 800;
            line-height: 24.59px;
            padding-bottom: 22px;
            color: #EA1555;
            font-family: "Manrope", sans-serif;
            font-style: normal;
        }

        .custom-sec3-main h3 {
            font-size: 32px;
            text-align: center;
            line-height: 60px;
            font-weight: 700;
            color: #000;
            font-family: "Manrope", sans-serif;
            font-style: normal;
            margin: 0 !important;
        }

        .custom-sec3-inner {
            padding: 50px 0px;
        }

        .custom-sec3-inner .custom-sec3-box {
            display: flex;
            padding: 72px 15px 77px 15px;
            flex-direction: column;
            align-items: center;
            border-radius: 20px;
            box-shadow: 0px 0px 4px 0px rgba(0, 0, 0, 0.25);
            background-color: #fff;
        }

        .custom-sec3-box figure {
            width: 100%;
            margin-bottom: 33px;
            height: 90.61px;
        }

        .custom-sec3-box figure img {
            margin: auto;
            display: block;
        }

        .custom-sec3-box h5 {
            font-size: 24px;
            text-align: center;
            line-height: 28px;
            font-weight: 700;
            max-width: 242px;
            color: #000;
            font-family: "Manrope", sans-serif;
            font-style: normal;
            margin: 0 !important;
        }

        .custom-sec3-viewAllBtn {
            width: 145px;
            height: 65px;
            font-size: 20px;
            line-height: 27.32px;
            text-decoration: none;
            font-weight: 500;
            display: flex;
            flex-direction: row;
            align-items: center;
            justify-content: center;
            border-radius: 10px;
            transition: 0.3s ease;
            font-family: "Manrope", sans-serif;
            font-style: normal;
            border: 1px solid #EA1555;
            color: #EA1555 !important;
        }

        .custom-sec3-viewAllBtn:hover {
            background-color: #EA1555;
            border: 1px solid #EA1555;
            color: #fff !important;
        }

        @media(max-width:991px) {
            .custom-sec3 {
                padding: 0px 15px 50px 15px;
                text-align: center;
            }

            .custom-sec3-main small {
                font-size: 16px;
                line-height: 20px;
                padding-bottom: 10px;

            }

            .custom-sec3-main h3 {
                font-size: 24px;
                line-height: 40px;
            }

            .row.custom-sec3-inner {
                margin: 0 -7.5px !important;
                padding: 30px 0;
            }

            .row.custom-sec3-inner .col-md-4 {
                padding: 0 7.5px !important;
            }

            .custom-sec3-viewAllBtn {
                width: 132px;
                height: 40px;
                font-size: 16px;
                line-height: 21.86px;
                border-radius: 10px;
            }

            .custom-sec3-inner .custom-sec3-box {
                padding: 40px 15px 40px 15px
            }

            .custom-sec3-box h5 {
                font-size: 18px;
                text-align: center;
                line-height: 23px;
                font-weight: 700;
                max-width: 181px;
                color: #000;
                font-family: "Manrope", sans-serif;
                font-style: normal;
                margin: 0 !important;
            }

        }

        @media(max-width: 768px) {
            .custom-sec3 {
                padding: 0px 15px 40px 15px;
            }

            .row.custom-sec3-inner {
                row-gap: 16px;
                justify-content: center;
            }
        }

        @media(max-width:576px) {
            .custom-sec3 {
                padding: 0px 13px 30px 13px;
            }

            .custom-sec3-main small {
                font-size: 14px;
                line-height: 20px;
                padding-bottom: 8px;

            }

            .custom-sec3-main h3 {
                font-size: 20px;
                line-height: 25px;
            }

            .custom-sec3-viewAllBtn {
                width: 105px;
                height: 25px;
                font-size: 10px;
                line-height: 13.66px;
                border-radius: 5px;
            }
              .custom-sec3-inner .custom-sec3-box { 
                            max-width: 293px;
                            margin: 0 auto;
                         }

        }
    </style>  
    <!-- custom- sec 3 comprehensive solution section start -->
    <div class="custom-sec3">
        <div class="custom-container">
            <div class="custom-sec3-main">
                <small>We can fix that</small>
                <h3> Comprehensive Solutions for All Your Mobile Needs </h3>
                <div class="row custom-sec3-inner">
                    <div class="col-sm-6 col-md-4">
                        <div class="custom-sec3-box h-100">
                            <figure>
                                <img src="https://ik.imagekit.io/myfirstKit/irepairLondon/WecanRepair/Vector%20(4).png" alt="">
                            </figure>
                            <h5>Mobile Charging Doc Replacement</h5>
                        </div>
                    </div>
                    <!-- 2 -->
                    <div class="col-sm-6 col-md-4">
                        <div class="custom-sec3-box h-100">
                            <figure>
                                <img src="https://ik.imagekit.io/myfirstKit/irepairLondon/WecanRepair/material-symbols_rule-settings.png" alt="">
                            </figure>
                            <h5>Mobile Battery Replacement</h5>
                        </div>
                    </div>
                    <!-- 3 -->
                    <div class="col-sm-6 col-md-4">
                        <div class="custom-sec3-box h-100">
                            <figure>
                                <img src="https://ik.imagekit.io/myfirstKit/irepairLondon/WecanRepair/tabler_battery-4.png" alt="">
                            </figure>
                            <h5>Mobile Screen Repair</h5>
                        </div>
                    </div>
                </div>
                <a class="mx-auto custom-sec3-viewAllBtn" href="/device-types/4">See All</a>
            </div>
        </div>

    </div>
    <!-- custom- sec 3 comprehensive solution section end -->
</div>